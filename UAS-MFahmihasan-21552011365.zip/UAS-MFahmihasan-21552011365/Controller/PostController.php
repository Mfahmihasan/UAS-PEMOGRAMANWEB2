<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\view\view;
use Illuminate\Http\Request;

class PostController extends Controller
{
    /** 
     * Display a listing of the resource.
     * 
     * @return View
     */ 
    public function index(): View
    {
        return view ('posts.index');
    }
    public function index(): View
    {
        return view ('posts.view');
    }
    public function index(): View
    {
        return view ('posts.edit');
    }
    public function index(): View
    {
        return view ('posts.login');
    }
}
